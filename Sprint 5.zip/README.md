# Project 5: Around The U.S.
## Project name
    Around the U.S.
### Overview  
  
**Intro**
  
This project is about Jacques cousteau who is an explorer and travelled around the US.. This webpage showcasing different places he travelled.
And it has a functionality for users to like the scenaries. In this project viewer can edit the profile and can add new places and aslo can delete the images with the smooth transition.

 **Tecnologies** 
 It contanis Html5, CSS, and javascript and abale to support reactive functionalities. javascript is used to rendered the images, data and content and to delete the content.  The project is hosted by the git which you can share with other developers. And this project is formatted and well structured using prettier.
**Figma** 
* [Link to the project on Figma]https://www.figma.com/design/JFPhASqvZ5pBjQV2ouUlim/Sprint-5_-Around-The-U.S.-_-desktop-%2B-mobile-(Copy)?node-id=1-398&node-type=frame&t=zzSHn9uXG5z4lRmG-0
  
**Images**  
  
![mobile design](image.png)  ![desktop design](image-1.png)

![Edit form ](image-2.png)    ![Add form] ![alt text](image.png)

![Preview Image in Desktop design]   ![alt text](image-1.png)   
![Preview in Mobile design] ![alt text](image-2.png)
  
**Github link**
https://github.com/dsrlg/se_project_aroundtheus

**Github docs**
https://dsrlg.github.io/se_project_aroundtheus/index.html

**Video**

https://www.loom.com/share/9ebec823332246ed8109c3e4ca9f63af